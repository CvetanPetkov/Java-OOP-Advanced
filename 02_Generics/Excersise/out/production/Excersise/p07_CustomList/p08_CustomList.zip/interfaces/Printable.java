package p07_CustomList.interfaces;

/**
 * Created by dell on 27-Jul-16.
 */
public interface Printable<T> {

    String printElements();

}
