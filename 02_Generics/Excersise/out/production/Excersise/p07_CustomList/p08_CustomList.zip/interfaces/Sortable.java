package p07_CustomList.interfaces;

/**
 * Created by dell on 29-Jul-16.
 */
public interface Sortable<T> {

    void sort();

}
