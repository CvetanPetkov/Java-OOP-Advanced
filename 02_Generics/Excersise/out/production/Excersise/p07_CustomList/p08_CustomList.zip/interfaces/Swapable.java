package p07_CustomList.interfaces;

/**
 * Created by dell on 27-Jul-16.
 */
public interface Swapable<T> {

    void swapElement(int index1, int index2);

}
