package p08_Tuple;

/**
 * Created by dell on 29-Jul-16.
 */
public interface Tuple<T> {

    T getKey();

    T getValue();

}
