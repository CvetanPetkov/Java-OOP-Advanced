package p08_Tuple;

/**
 * Created by dell on 29-Jul-16.
 */
public class TupleImpl<T> implements Tuple {

    private T item1;
    private T item2;

    public TupleImpl(T item1, T item2) {
        this.setItem1(item1);
        this.setItem2(item2);
    }

    private void setItem1(T item1) {
        this.item1 = item1;
    }

    private void setItem2(T item2) {
        this.item2 = item2;
    }

    @Override
    public T getKey() {
        return this.item1;
    }

    @Override
    public T getValue() {
        return this.item2;
    }

    @Override
    public String toString() {
        return String.format("%s -> %s",
                this.getKey(), this.getValue());
    }

}
