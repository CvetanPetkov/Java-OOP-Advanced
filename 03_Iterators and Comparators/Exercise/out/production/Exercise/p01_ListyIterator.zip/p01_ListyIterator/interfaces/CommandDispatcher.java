package p01_ListyIterator.interfaces;

/**
 * Created by dell on 31-Jul-16.
 */
public interface CommandDispatcher {

    void dispatch(String[] input);

}
