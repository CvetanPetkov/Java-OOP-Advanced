package p01_ListyIterator.interfaces;

/**
 * Created by dell on 30-Jul-16.
 */
public interface Iterable {

    boolean move();

    boolean hasNext();

    void print();

}
