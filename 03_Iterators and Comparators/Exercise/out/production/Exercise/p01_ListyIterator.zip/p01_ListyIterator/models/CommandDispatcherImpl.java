package p01_ListyIterator.models;

import p01_ListyIterator.interfaces.CommandDispatcher;
import p01_ListyIterator.interfaces.Factory;
import p01_ListyIterator.interfaces.Iterable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 31-Jul-16.
 */
public class CommandDispatcherImpl implements CommandDispatcher{

    private List<String> list;
    private Iterable listyIterator;

    public CommandDispatcherImpl() {
        this.list = new ArrayList<>();
        this.listyIterator = new ListyIterator();
    }

    private void setList(List<String> list) {
        this.list = list;
    }

    private void setListyIterator(List<String> list) {
        this.listyIterator = new ListyIterator(list);
    }

    @Override
    public void dispatch(String[] input) {
        switch (input[0]) {
            case "Create":
                Factory factory = new FactoryImpl();
                factory.addElements(input);
                setList(factory.getList());
                setListyIterator(this.list);
                break;
            case "Move":
                System.out.println(listyIterator.move());
                break;
            case "Print":
                listyIterator.print();
                break;
            case "HasNext":
                System.out.println(listyIterator.hasNext());
                break;
        }
    }
}
