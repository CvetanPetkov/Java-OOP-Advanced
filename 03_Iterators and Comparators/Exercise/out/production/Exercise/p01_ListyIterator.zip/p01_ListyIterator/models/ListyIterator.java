package p01_ListyIterator.models;

import p01_ListyIterator.interfaces.Iterable;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dell on 30-Jul-16.
 */
public class ListyIterator implements Iterable{

    private List<String> collection;
    private int currIndex;

    public ListyIterator() {
        this.setCollection(new ArrayList<String>());
        this.currIndex = 0;
    }

    public ListyIterator(List<String> collection) {
        this.setCollection(collection);
    }

    private void setCollection(List<String> collection) {
        this.collection = collection;
    }

    @Override
    public boolean move() {
        if (this.hasNext()) {
            this.currIndex++;
            return true;
        }
        return false;
    }

    @Override
    public boolean hasNext() {
        return this.currIndex < this.collection.size() -1;
    }

    @Override
    public void print() {
        System.out.println(this.collection.get(currIndex));
    }
}
