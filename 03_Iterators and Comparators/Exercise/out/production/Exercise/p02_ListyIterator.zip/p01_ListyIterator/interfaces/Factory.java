package p01_ListyIterator.interfaces;

import java.util.List;

/**
 * Created by dell on 31-Jul-16.
 */
public interface Factory {

    List<String> getList();

    void addElements(String[] input);
}
