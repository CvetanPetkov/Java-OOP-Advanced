package p01_ListyIterator.interfaces;

/**
 * Created by dell on 30-Jul-16.
 */
public interface ListIterator {

    boolean move();

    boolean hasNext();

    void print();

    void printAll();

}
