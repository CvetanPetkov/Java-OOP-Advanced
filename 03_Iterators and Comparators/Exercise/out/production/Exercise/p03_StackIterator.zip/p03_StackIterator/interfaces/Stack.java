package p03_StackIterator.interfaces;

/**
 * Created by dell on 31-Jul-16.
 */
public interface Stack extends Iterable<Integer> {

    void push(Integer i);

    void pop();

}
