package p04_CardToString.enums;

/**
 * Created by dell on 01-Aug-16.
 */
public enum Suit {

    CLUBS(0),
    DIAMONDS(13),
    HEARTS(26),
    SPADES(39);

    private int power;

    Suit(int power) {
        this.power = power;
    }

    public int getPower() {
        return this.power;
    }

}
