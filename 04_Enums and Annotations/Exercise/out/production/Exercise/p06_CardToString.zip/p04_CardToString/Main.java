package p04_CardToString;

import p04_CardToString.enums.Rank;
import p04_CardToString.enums.Suit;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by dell on 01-Aug-16.
 */
public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String type = reader.readLine();
        Class<Rank> cl1 = Rank.class;
        Class<Suit> cl2 = Suit.class;
        CustomAnotation annotation;
        annotation = type.equals("Rank") ?
                cl1.getAnnotation(CustomAnotation.class) :
                cl2.getAnnotation(CustomAnotation.class);

        System.out.printf("Type = %s, Description = %s",annotation.type(),annotation.description());

    }
}
