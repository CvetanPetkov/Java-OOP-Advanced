package p06_DeckOfCards;

import p06_DeckOfCards.enums.Rank;
import p06_DeckOfCards.enums.Suit;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Created by dell on 01-Aug-16.
 */
public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String input = reader.readLine();

        for (Suit suit : Suit.values()) {
            for (Rank rank : Rank.values()) {
                System.out.println(rank.name() + " of " + suit.name());
            }
        }
    }
}
