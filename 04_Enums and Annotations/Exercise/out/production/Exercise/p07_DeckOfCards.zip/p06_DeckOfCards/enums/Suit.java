package p06_DeckOfCards.enums;

public enum Suit {

    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES

}
