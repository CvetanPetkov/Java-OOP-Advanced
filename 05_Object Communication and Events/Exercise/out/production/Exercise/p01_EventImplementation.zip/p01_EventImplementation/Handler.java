package p01_EventImplementation;

/**
 * Created by dell on 02-Aug-16.
 */
public class Handler implements NameChangeListener {

    @Override
    public void handleChangedName(NameChange event) {
        System.out.println("Dispatcher's name changed to " +
        event.getChangedName() + ".");
    }
}
