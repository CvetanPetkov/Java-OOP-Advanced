package p01_EventImplementation;

/**
 * Created by dell on 02-Aug-16.
 */
public interface NameChangeListener {

    void handleChangedName(NameChange event);
}