package p02_KingsGambit.contracts;

/**
 * Created by dell on 02-Aug-16.
 */
public interface King {

    void killUnit(String unitToKill);

    void attackKing();

    String getName();

    void addUnit(Unit unit);
}
