package p02_KingsGambit.contracts;

/**
 * Created by dell on 02-Aug-16.
 */
public interface Unit {

    String getName();

    String getTypeOfUnit();

    String attackUnit();
}
